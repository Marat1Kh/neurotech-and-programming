package com.epam.rd.autotasks.figures;

public class Main {
    public static void main(String[] args) {



    }
}
