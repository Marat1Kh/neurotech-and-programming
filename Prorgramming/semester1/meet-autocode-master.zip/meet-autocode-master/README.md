# Meet Autocode

The purpose of this exercise is to make you familiar with the Autocode platform.

Estimated workload of this exercise is _5 minutes_.

### Description
Please, proceed to [HelloAutocode](src/main/java/com/epam/rd/autotasks/meetautocode/HelloAutocode.java) class
and write a simple program that prints "Hello, Autocode!" (don't print quote marks).
