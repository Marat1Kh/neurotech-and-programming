package com.epam.rd.autotasks.meetautocode;

public class HelloAutocode {
    public static void main(String[] args) {
        System.out.println("Hello, Autocode!");
        //Write a program, printing "Hello, Autocode!"

    }
}
