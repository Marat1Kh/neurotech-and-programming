# Meet a stranger

The purpose of this exercise is to familiarize you with basic usage of standard input stream.

Estimated workload of this exercise is _5 minutes_.

### Description
Please, proceed to the class [MeetAStranger](src/main/java/com/epam/rd/autotasks/meetastranger/MeetAStranger.java).
The program must read a string from System.in and print a message "Hello, *input*".

Note that when entering an input string consisting of several words, the entire input must be printed.

### Example

---
Input: `Mrs. Robinson`

Output: `Hello, Mrs. Robinson`

---