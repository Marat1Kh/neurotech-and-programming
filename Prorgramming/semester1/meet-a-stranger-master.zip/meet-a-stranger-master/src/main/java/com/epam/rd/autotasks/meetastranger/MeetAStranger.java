package com.epam.rd.autotasks.meetastranger;
import java.util.Scanner;
public class MeetAStranger {
    public static void main(String[] args) {
       Scanner name = new Scanner (System.in);
       String uname;
       System.out.println();
       uname=name.nextLine();
       System.out.println("Hello, "+uname);

    }
}
