package com.epam.rd.autotasks;

public class LazySortingImpl extends Sorting{

    @Override
    public void sort(int[] array) {
        //Whatever...
    }
}
