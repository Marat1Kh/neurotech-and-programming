# Employees. SQL Queries.

## Description 
Fill SQL queries in [`com.epam.rd.tasks.sqlqueries.SqlQueries`](src/main/java/com/epam/rd/tasks/sqlqueries/SqlQueries.java).

You may refer to DDL in [`init-ddl.sql`](src/test/resources/init-ddl.sql).
 