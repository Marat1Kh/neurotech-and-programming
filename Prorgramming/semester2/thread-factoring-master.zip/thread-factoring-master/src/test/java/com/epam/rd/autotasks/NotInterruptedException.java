package com.epam.rd.autotasks;

public class NotInterruptedException extends RuntimeException {
}
