package com.epam.rd.autocode.dao;

import java.math.BigInteger;

import com.epam.rd.autocode.domain.Department;

public interface DepartmentDao extends Dao<Department, BigInteger> {

}

