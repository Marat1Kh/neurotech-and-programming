package com.epam.rd.autocode.factory.plot;

public interface EpicCrisis {
    String name();
}
