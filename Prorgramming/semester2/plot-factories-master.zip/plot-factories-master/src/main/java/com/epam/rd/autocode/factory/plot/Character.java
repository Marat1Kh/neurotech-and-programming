package com.epam.rd.autocode.factory.plot;

public interface Character {
    String name();
}
