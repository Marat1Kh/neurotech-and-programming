package com.epam.rd.autocode.factory.plot;

public interface Plot {
    String asText();
}
